public class InToPost
{
    public static void main(String[] args)
    {
        String[] expression = args[0].split(" ");
        String[] output = new String[expression.length];
        Stack s = new Stack(expression.length);

        int temp = -1;

        for(int i = 0; i < expression.length; i++)
        {
            if( Character.isDigit( expression[i].charAt(0) ) )
                output[++temp] = expression[i];
            else if(expression[i].charAt(0) == '(')
                s.push( expression[i] );
            else if(expression[i].charAt(0) == ')')
            {
                while((s.peek()).charAt(0) != '(')
                    output[++temp] = s.pop();
        
                s.pop();
            }
            else
            {
                boolean i1 = true;

                while(i1)
                {
                    if(s.isEmpty())
                    {
                        s.push( expression[i] );
                        i1 = false;                 
                    }
                    else if((s.peek()).charAt(0) == '(')
                    {
                        s.push( expression[i] );                 
                        i1 = false;
                    }
                    else if( priority( expression[i].charAt(0), (s.peek()).charAt(0) ) )
                    {
                        s.push( expression[i] );                 
                        i1 = false;
                    }
                    else
                    {
                        output[++temp] = s.pop();
                    }
                }
            }
        
            if(i == expression.length - 1)
            {
                while(!s.isEmpty())
                {
                    output[++temp] = s.pop();
                }               
            }
        }

        System.out.print("The output expression is ");

        for(String i: output)
            System.out.print(i + " ");

        temp = 0;

        while(temp != expression.length && output[temp] != null)
        {
            if( Character.isDigit( output[temp].charAt(0) ) )
            {
                s.push( output[temp] );
            }
            else
            {
                int op2 = Integer.parseInt( s.pop() );
                int op1 = Integer.parseInt( s.pop() );

                s.push( calculate(op1, output[temp].charAt(0), op2) );
            }

            temp++;
        }
        
        System.out.println("\nThe value of output expression is " + s.pop());
    }

    public static String calculate(int op1, char symbol, int op2)
    {
        switch(symbol)
        {
            case '*':
                return String.format("%d",op1 * op2);
            case '/':
                return String.format("%d",op1 / op2);
            case '+':
                return String.format("%d",op1 + op2);
            case '-':           
                return String.format("%d",op1 - op2);   
        }
        
        return null;
    }
    
    public static boolean priority(char inArray, char ins )
    {
        switch(inArray)
        {
            case '*':
                if(ins == '/' || ins == '*')
                {
                    return false;
                }
                else
                {
                    return true;
                }

            case '/':
                if(ins == '/' || ins == '*')
                {
                    return false;
                }
                else
                {
                    return true;
                }

            case '+':
            case '-':
                return false;               
        }

        return false;
    }
}

class Stack
{
    private int maxSize;
    private String[] array;
    private int top;

    Stack(int v)
    {
        maxSize = v;
        array = new String[maxSize];
        top = -1;
    }

    void push(String v)
    {
        array[++top] = v;   
    }

    String pop()
    {
        return array[top--];
    }

    String peek()
    {
        return array[top];
    }

    boolean isEmpty()
    {
        if(top == -1)
            return true;
        else 
            return false;
    }

    boolean isFull()
    {
        if(top == maxSize - 1)
            return true;
        else
            return false;
    }
}